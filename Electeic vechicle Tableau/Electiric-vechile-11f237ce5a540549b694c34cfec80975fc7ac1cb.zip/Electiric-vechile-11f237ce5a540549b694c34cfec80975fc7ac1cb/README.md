# Electiric-vechile


Dashboard public link - https://public.tableau.com/views/financialanalysis_168064778150/Dashboard1?:language=en-US&:display_count=n&:origin=viz_share_link

Story public link - https://public.tableau.com/views/story_16806964113910/Story1?:language=en-US&:display_count=n&:origin=viz_share_lonk

Video demonstartion Link = 
